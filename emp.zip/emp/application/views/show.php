<!DOCTYPE html>
<html>
<head>
<title>Student Data</title>
</head>

<body>
    <!-- <?php
      echo "<pre>";print_r($users);
    ?> -->
	<form method="post">
		<table width="600" align="center" border="1" cellspacing="5" cellpadding="5">
	<tr>
    <th colspan="2">Name</th>
    <th colspan="2">Email</th>
    <th colspan="2">Isadmin</th>
    <th colspan="2">Action</th>
  </tr>
  <?php for($i=0;$i<count($users);$i++) { ?>
  <tr>
		<td colspan="2"><?php echo $users[$i]['name']; ?></td>
    <td colspan="2"><?php echo $users[$i]['email']; ?></td>
    <td colspan="2"><?php if(array_key_exists('isadmin',$users[$i])) echo "YES"; else echo "NO";?></td>
    <td colspan="2"></td>
	</tr>	
  <?php } ?>
  
  <tr>
    <td colspan="8" align="center">
	<a href ="logout">logout</a></td>
  </tr>
</table>

	</form>
</body>
</html>