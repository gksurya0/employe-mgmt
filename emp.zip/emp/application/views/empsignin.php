<!DOCTYPE html>
<html>
<head>
<title>Sign in</title>
</head>

<body>
	<form method="post">
		<table width="600" align="center" border="1" cellspacing="5" cellpadding="5">
	<tr>
		<td colspan="2"><?php echo @$error; ?></td>
	</tr>	
  <tr>
    <td width="230">Enter Username </td>
    <td width="329"><input type="text" name="name"/></td>
  </tr>
  
  
  <tr>
    <td>Enter Your Password </td>
    <td><input type="password" name="pass"/></td>
  </tr>

  
  <!--<tr>
    <td>Select Your Course </td>
    <td>
	<select name="course">
		<option value="">Select Course</option>
		<option>PHP</option>
		<option>Java</option>
		<option>Wordpress</option>
	</select>
	</td>
  </tr>-->
  <tr>
    <td colspan="2" align="center">
	<input type="submit" name="signin" value="Sign In"/></td>
  <td><a href ="../user">Sign Up</a></td>
  </tr>
</table>

	</form>
</body>
</html>