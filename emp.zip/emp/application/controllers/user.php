<?php
class User extends CI_Controller 
{
	public function __construct()
	{
	parent::__construct();
	$this->load->database();
	$this->load->helper('url');
	}

	public function index()
	{
		
		if($this->input->post('register'))
		{
			$dt = $this->input->post();
		$n=$this->input->post('name');
		$e=$this->input->post('email');
		$p=$this->input->post('pass');
		$p1=$this->input->post('pass1');
		$c=$this->input->post('course');
		
		$inp = file_get_contents('results.json');
		$tempArray = json_decode($inp,TRUE);
		//echo "<pre>";print_r($tempArray);
		$row = 0;
		for($i=0;$i<count($tempArray);$i++) {
			if($tempArray[$i]['name']==$n) {
					//echo "pls login";
					$row = 1; 
					break;
				}
		}
		//$que=$this->db->query("select * from student where email='".$e."'");
		//$row = $que->num_rows();
		if($p!=$p1)
		{
		$data['error']="<h3 style='color:red'>Password Not Matched.</h3>";
		}
		else if($row == 1)
		{
		$data['error']="<h3 style='color:red'>This user already exists</h3>";
		}
		else
		{
			$inp = file_get_contents('results.json');
			$tempArray = json_decode($inp);
			if($tempArray==null) $tempArray=array();
			//echo "<pre>";print_r($tempArray);
			array_push($tempArray, $dt);
			$jsonData = json_encode($tempArray);
			file_put_contents('results.json', $jsonData);
		//$que=$this->db->query("insert into student values('','$n','$e','$p','$m','$c')");
		
		$data['error']="<h3 style='color:blue'>Your account created successfully</h3>";
		}			
				
		}
	$this->load->view('student_registration',@$data);	
	}
	public function showdata () {
		$inp = file_get_contents('results.json');
		$data['users'] = json_decode($inp,TRUE);
		//echo "<pre>";print_r($tempArray);
		$this->load->view('show',@$data);	
	}
	public function show_data () {
		$u = $this->session->userdata('username');
		$p = $this->session->userdata('password');
		$inp = file_get_contents('results.json');
		$data['users'] = array();
		//echo $u,$p;
		$tempArray = json_decode($inp,TRUE);
		for($i=0;$i<count($tempArray);$i++) {
			if($tempArray[$i]['name']==$u && $tempArray[$i]['pass']==$p) {
					$data['users'] = $tempArray[$i];
				}
		}
		//echo "<pre>";print_r($data['users']);
		$this->load->view('showuser',@$data);	
	}
	public function logout() {
		
			$this->session->unset_userdata('username');
			$this->session->unset_userdata('password');
			redirect('user/signin');
		
	}
	public function signin () {

		if($this->input->post('signin'))
		{
			$dt = $this->input->post();
			$n=$this->input->post('name');
		
			$p=$this->input->post('pass');
			//echo "<pre>";print_r($dt);
			$inp = file_get_contents('results.json');
			$tempArray = json_decode($inp,TRUE);
			//echo "<pre>";print_r($tempArray);die(0);
			for($i=0;$i<count($tempArray);$i++) {
				if($tempArray[$i]['name']==$n && $tempArray[$i]['pass']==$p) {
					//echo "pls login";die(0);
					//$this->load->library('session');
					$this->session->set_userdata('username', $n);
					//echo $this->session->userdata('username');die(0);
					$this->session->set_userdata('password', $p);
					if(array_key_exists('isadmin', $tempArray[$i]))
					{	$this->showdata(); return;//redirect('user/showdata');
					}
					else 
					{	$this->show_data(); return;//redirect('user/show_data');
					}
					break;
				} else {
					//echo "unsuccessfull";
				}
			}
		}
		$this->load->view('empsignin');	
	}
}
?>